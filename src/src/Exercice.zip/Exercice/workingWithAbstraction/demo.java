package Exercice.workingWithAbstraction;

public class demo {
}
