package Exercice.encaptulation;

public class demo {
}
